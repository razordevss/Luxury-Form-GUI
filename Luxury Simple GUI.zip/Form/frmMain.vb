﻿Imports System.CodeDom.Compiler
Imports System.IO
Imports System.IO.Compression
Imports System.Net
Imports System.Net.Http
Imports System.Runtime.CompilerServices
Imports System.Security.Cryptography
Imports System.Text
Imports Microsoft.CSharp
Imports Microsoft.VisualBasic.CompilerServices
Imports Microsoft.Win32
Imports System.Runtime.InteropServices
Imports System.Security
Imports System.Threading
Imports System.Timers


'  _ _  ____                            ____                 __                         _____ _                 __        ________  ______   ___         __ 
' ( | )/' __ \____ _____  ____  _____   / __ \___ _   _____  / /___  ____  ___  _____   / ___/(_)___ ___  ____  / /__     / ____/ / / /  _/  /   |  _____/ /_
' |/|// '/_/ / __ `/_  / / __ \/ ___/  / / / / _ \ | / / _ \/ / __ \/ __ \/ _ \/ ___/   \__ \/ / __ `__ \/ __ \/ / _ \   / / __/ / / // /   / /| | / ___/ __/
'    / _, _/ /_/ / / /_/ /_/ / /     / /_/ /  __/ |/ /  __/ / /_/ / /_/ /  __/ /      ___/ / / / / / / / /_/ / /  __/  / /_/ / /_/ // /   / ___ |/ /  / /_  
'   /_/ |_|\__,_/ /___/\____/_/     /_____/\___/|___/\___/_/\____/ .___/\___/_/      /____/_/_/ /_/ /_/ .___/_/\___/   \____/\____/___/  /_/  |_/_/   \__/  
'  _ _    ______            __             __     _____ __      /_/                   __             /_/        __                                          
' ( | )  / ____/___  ____  / /_____ ______/ /_   / ___// /____  ______  ___     _    / /___  _________ ______  / /_  ___  ____ ______                       
' |/|/  / /   / __ \/ __ \/ __/ __ `/ ___/ __/   \__ \/ //_/ / / / __ \/ _ \   (_)  / / __ \/ ___/ __ `/ ___/ / __ \/ _ \/ __ `/ ___/                       
'      / /___/ /_/ / / / / /_/ /_/ / /__/ /_    ___/ / ,< / /_/ / /_/ /  __/  _    / / /_/ / /  / /_/ (__  ) / /_/ /  __/ /_/ (__  )                        
'      \____/\____/_/ /_/\__/\__,_/\___/\__/   /____/_/|_|\__, / .___/\___/  (_)  /_/\____/_/   \__,_/____(_)_.___/\___/\__,_/____/                         
'                                                       /____/_/                                                                                           
'


Public Class frmMain
    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        FrmSettings1.BringToFront()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        FrmDashboard1.BringToFront()
    End Sub


    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        FrmDashboard1.BringToFront()
        Guna2ShadowForm1.SetShadowForm(Me)

        ServicePointManager.Expect100Continue = True
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Me.WindowState = FormWindowState.Normal

        Me.MinimumSize = Me.Size

        Me.MaximumSize = Me.Size

    End Sub



    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click

    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        FrmBuild1.BringToFront()
    End Sub

    Private Sub Guna2PictureBox2_Click(sender As Object, e As EventArgs) Handles Guna2PictureBox2.Click
        Guna2Button6.Checked = True
        FrmAccount1.BringToFront()
    End Sub

    Private Sub Guna2Button6_Click(sender As Object, e As EventArgs) Handles Guna2Button6.Click
        FrmAccount1.BringToFront()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click

    End Sub

    Private Sub Guna2Button8_Click(sender As Object, e As EventArgs) Handles Guna2Button8.Click
        Environment.Exit(1)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick

    End Sub

    Private Sub Guna2PictureBox1_Click(sender As Object, e As EventArgs) Handles Guna2PictureBox1.Click

    End Sub
End Class

